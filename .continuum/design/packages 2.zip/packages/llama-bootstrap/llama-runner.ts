import { execSync } from 'child_process'
import fs from 'fs'
import path from 'path'

const session = 'llama'
const logFile = path.resolve(__dirname, './llama-output.log')

// Sends a prompt to the LLaMA tmux session
export function sendPrompt(prompt: string) {
  const safe = prompt.replace(/"/g, '\\"')
  const cmd = `tmux send-keys -t ${session} "${safe}" C-m`
  execSync(cmd)
}

// Retrieves latest response from the LLaMA output log
export function getLatestResponse(): string {
  if (!fs.existsSync(logFile)) return ''
  const data = fs.readFileSync(logFile, 'utf-8')
  return data.split('\n').slice(-10).join('\n')
}
