import { Agent, Task } from '../types'

export const LlamaAgent: Agent = {
  name: 'llama-local',
  costEstimate: (_) => 0,

  capabilities: ['lookup', 'file_search', 'indexing'],

  async run(task: Task): Promise<string> {
    // Replace with local inference call (e.g. llama.cpp)
    return `[LLaMA handled: ${task.prompt}]`
  },
}
